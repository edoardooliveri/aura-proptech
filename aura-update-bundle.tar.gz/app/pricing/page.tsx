"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import {
  Zap, Check, ArrowRight, Bot, Globe, MessageCircle,
  BarChart3, Palette, Shield, Headphones, Star,
  Sparkles, Loader2, X, Crown, Rocket,
} from "lucide-react";

// ── Smooth animation helpers ────────────────────────────────────
const ease = [0.16, 1, 0.3, 1] as const;

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 40, filter: "blur(10px)" } as const,
  animate: { opacity: 1, y: 0, filter: "blur(0px)" } as const,
  transition: { duration: 0.8, delay, ease } as const,
});

const fadeUpView = (delay = 0) => ({
  initial: { opacity: 0, y: 40, filter: "blur(8px)" } as const,
  whileInView: { opacity: 1, y: 0, filter: "blur(0px)" } as const,
  viewport: { once: true, margin: "-60px" as const },
  transition: { duration: 0.7, delay, ease } as const,
});

// ── Piani ────────────────────────────────────────────────────────
const plans = [
  {
    id: "starter",
    name: "Aura Starter",
    icon: Globe,
    badge: "BASE",
    badgeColor: "#64748b",
    setup: 399.99,
    monthly: 24.99,
    setupLabel: "€399,99",
    monthlyLabel: "€24,99",
    desc: "Il sito web professionale per la tua agenzia. Perfetto per chi vuole una presenza online moderna senza AI.",
    highlight: false,
    features: [
      "Sito web professionale responsive",
      "Design dark/light personalizzato",
      "Pannello admin intuitivo",
      "Database immobili con gestione portfolio",
      "Hosting e dominio inclusi",
      "Supporto email",
      "Aggiornamenti di sicurezza continui",
    ],
    notIncluded: [
      "AI Concierge",
      "Qualificazione lead automatica",
      "WhatsApp Business",
      "Report mensile efficienza",
    ],
    ctaLabel: "SCEGLI STARTER",
  },
  {
    id: "professional",
    name: "Aura Professional",
    icon: Rocket,
    badge: "POPOLARE",
    badgeColor: "#0070F3",
    setup: 999.99,
    monthly: 149.99,
    setupLabel: "€999,99",
    monthlyLabel: "€149,99",
    desc: "Sito web + AI Concierge che risponde ai tuoi clienti 24/7. Il pacchetto ideale per agenzie in crescita.",
    highlight: true,
    features: [
      "Tutto di Starter, più:",
      "AI Concierge 24/7 personalizzata",
      "Qualificazione lead automatica",
      "Integrazione WhatsApp Business",
      "Report mensile sull'efficienza",
      "Personalizzazione brand e tone of voice",
      "Training AI sulle tue zone e portfolio",
      "Supporto prioritario email e chat",
    ],
    notIncluded: [
      "AI multilingue avanzata",
      "Dashboard analytics custom",
      "Account manager dedicato",
    ],
    ctaLabel: "SCEGLI PROFESSIONAL",
  },
  {
    id: "enterprise",
    name: "Aura Enterprise",
    icon: Crown,
    badge: "PREMIUM",
    badgeColor: "#FF2D78",
    setup: 1999.99,
    monthly: 199.99,
    setupLabel: "€1.999,99",
    monthlyLabel: "€199,99",
    desc: "L'esperienza completa. AI avanzata multilingue, analytics custom, account manager dedicato e integrazioni su misura.",
    highlight: false,
    features: [
      "Tutto di Professional, più:",
      "AI Concierge multilingue avanzata",
      "Flussi WhatsApp automatizzati",
      "Dashboard analytics personalizzata",
      "Account manager dedicato",
      "Integrazioni CRM su misura",
      "Priorità su aggiornamenti e nuove feature",
      "Onboarding premium con strategia AI",
      "SLA garantito su tempi di risposta",
    ],
    notIncluded: [],
    ctaLabel: "SCEGLI ENTERPRISE",
  },
];

// ── Servizi inclusi ─────────────────────────────────────────────
const services = [
  {
    icon: Bot,
    title: "AI Concierge Personalizzata",
    desc: "Assistente AI che parla con la voce della tua agenzia. Nome, personalità, tone of voice — tutto configurato sul tuo brand. Risponde in < 2 secondi, 24/7/365.",
    tag: "CORE",
    plans: ["professional", "enterprise"],
  },
  {
    icon: Globe,
    title: "Sito Web di Lusso",
    desc: "Un sito immobiliare premium, progettato per convertire. Design dark/light, responsive, con gestione portfolio integrata e pannello admin zero-competenze.",
    tag: "INCLUSO",
    plans: ["starter", "professional", "enterprise"],
  },
  {
    icon: MessageCircle,
    title: "Integrazione WhatsApp Business",
    desc: "Core AI risponde anche su WhatsApp. I tuoi clienti scrivono dove preferiscono — l'AI cattura, qualifica e prenota. Tutto converge nel pannello unico.",
    tag: "BETA",
    plans: ["professional", "enterprise"],
  },
  {
    icon: BarChart3,
    title: "Report Mensile sull'Efficienza",
    desc: "Ogni mese ricevi un report dettagliato: lead generati, tempo risparmiato, tasso di conversione, ROI reale. Numeri concreti, non metriche vanity.",
    tag: "ANALYTICS",
    plans: ["professional", "enterprise"],
  },
  {
    icon: Palette,
    title: "Personalizzazione Totale",
    desc: "Colori, logo, nome dell'assistente, tono. Nessun template generico. Il tuo cliente vedrà un'estensione naturale del tuo team — non un prodotto di terzi.",
    tag: "BRANDING",
    plans: ["professional", "enterprise"],
  },
  {
    icon: Shield,
    title: "Database Immobili Real-Time",
    desc: "Aggiungi, modifica, rimuovi proprietà dal pannello admin. Core AI si aggiorna istantaneamente. Zero rischio di dati obsoleti o immobili fantasma.",
    tag: "REAL-TIME",
    plans: ["starter", "professional", "enterprise"],
  },
];

// ── Tutto incluso ─────────────────────────────────────────────
const included = [
  "Setup e onboarding in 7 giorni",
  "Migrazione contenuti dal tuo sito attuale",
  "Configurazione brand completa (colori, logo, tono)",
  "Training AI sulle tue zone e il tuo portfolio",
  "Pannello admin intuitivo con tutorial",
  "Integrazione WhatsApp Business API",
  "Report efficienza mensile automatico",
  "Supporto tecnico prioritario via email e chat",
  "Aggiornamenti e miglioramenti AI continui",
  "Nessun vincolo annuale — disdici quando vuoi",
];

// ── FAQ ───────────────────────────────────────────────────────
const faqs = [
  {
    q: "Quanto ci vuole per andare live?",
    a: "7 giorni dal pagamento del setup. Giorno 1: call di onboarding + raccolta dati. Giorni 2-5: configurazione, design e test. Giorni 6-7: revisione finale e go-live.",
  },
  {
    q: "Qual è la differenza tra i piani?",
    a: "Starter è solo il sito web professionale, senza AI. Professional aggiunge l'AI Concierge che risponde ai tuoi clienti 24/7 e qualifica i lead automaticamente. Enterprise include tutto, con AI multilingue avanzata, analytics custom, account manager dedicato e integrazioni CRM su misura.",
  },
  {
    q: "Posso disdire quando voglio?",
    a: "Sì. Nessun contratto annuale. Paghi mese per mese. Se disdici, il servizio si ferma alla fine del mese pagato. Il setup non è rimborsabile.",
  },
  {
    q: "E se non ho un sito?",
    a: "Perfetto. Tutti i piani includono un sito web premium progettato per convertire. Non devi fare nulla — lo costruiamo noi basandoci sul tuo brand.",
  },
  {
    q: "L'AI risponde anche su WhatsApp?",
    a: "Sì, nei piani Professional e Enterprise. Core AI è integrato con WhatsApp Business API. I tuoi clienti scrivono su WhatsApp, l'AI risponde, qualifica il lead e ti notifica quando è caldo.",
  },
  {
    q: "Come gestite i dati dei miei clienti?",
    a: "Database dedicato per ogni agenzia. Nessuna condivisione di dati tra clienti. Hosting europeo, compliant GDPR. I tuoi dati sono tuoi — sempre.",
  },
  {
    q: "Posso passare a un piano superiore?",
    a: "Certo, in qualsiasi momento. L'upgrade è istantaneo e paghi solo la differenza di canone mensile. Il setup aggiuntivo dipende dal piano scelto.",
  },
];

export default function PricingPage() {
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null);

  async function handleCheckout(planId: string) {
    if (checkoutLoading) return;
    setCheckoutLoading(planId);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan: planId }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        console.error("Checkout error:", data.error);
        alert(data.error || "Errore durante il checkout. Riprova.");
        setCheckoutLoading(null);
      }
    } catch (err) {
      console.error("Checkout error:", err);
      alert("Errore di connessione. Verifica la tua rete e riprova.");
      setCheckoutLoading(null);
    }
  }

  return (
    <div className="min-h-screen bg-black text-white relative">

      {/* ── NEON GLOW ORBS ─────────────────────────────────────── */}
      <div className="neon-orb-pink" style={{ top: "-200px", right: "-200px" }} />
      <div className="neon-orb-blue" style={{ top: "30%", left: "-300px" }} />
      <div className="neon-orb-purple" style={{ bottom: "20%", right: "-200px", opacity: 0.6 }} />
      <div className="neon-orb-blue" style={{ bottom: "-200px", left: "20%", opacity: 0.4 }} />

      {/* ── Navbar ──────────────────────────────────────────────── */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 lg:px-12 h-16 glass-strong">
        <Link href="/" className="flex items-center gap-2.5">
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #0070F3, #7B2FFF)" }}
          >
            <Zap size={14} className="text-white" />
          </div>
          <span className="font-mono font-bold text-sm tracking-tight">
            AURA<span className="gradient-blue">PROPTECH</span>
          </span>
        </Link>
        <div className="flex items-center gap-4">
          <Link
            href="/#demo"
            className="text-sm font-mono hover:text-white transition-colors duration-300"
            style={{ color: "var(--text-secondary)" }}
          >
            Demo
          </Link>
          <Link
            href="/#problema"
            className="text-sm font-mono hover:text-white transition-colors duration-300 hidden md:block"
            style={{ color: "var(--text-secondary)" }}
          >
            Come funziona
          </Link>
        </div>
      </nav>

      <main className="pt-16 relative z-10">

        {/* ── HERO PRICING ──────────────────────────────────────── */}
        <section className="relative py-24 md:py-32 px-6 text-center overflow-hidden">
          <div className="absolute inset-0 grid-bg pointer-events-none" />

          <div className="relative max-w-4xl mx-auto">
            <motion.div
              {...fadeUp(0)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-mono mb-10 pulse-glow"
              style={{
                background: "rgba(255,45,120,0.08)",
                border: "1px solid rgba(255,45,120,0.25)",
                color: "#FF2D78",
              }}
            >
              <Sparkles size={12} />
              Tre piani. Un unico obiettivo: far crescere la tua agenzia.
            </motion.div>

            <motion.h1
              {...fadeUp(0.1)}
              className="font-mono text-5xl md:text-6xl lg:text-7xl font-bold leading-[1] tracking-tighter mb-6"
            >
              <span style={{ color: "var(--text-primary)" }}>Scegli il piano </span>
              <span className="gradient-hero">perfetto per te</span>
            </motion.h1>

            <motion.p
              {...fadeUp(0.2)}
              className="text-xl md:text-2xl max-w-2xl mx-auto mb-4"
              style={{ color: "var(--text-secondary)" }}
            >
              Dal sito web professionale all&apos;AI completa.
              Ogni piano è progettato per il tuo livello di crescita.
            </motion.p>
          </div>
        </section>

        {/* ── PRICING CARDS — i tre piani ─────────────────────── */}
        <section className="px-6 -mt-8 mb-28">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-3 gap-6">
            {plans.map((plan, idx) => (
              <motion.div
                key={plan.id}
                {...fadeUp(0.2 + idx * 0.1)}
                className="relative"
              >
                {/* Animated border for highlighted plan */}
                <div
                  className={`rounded-3xl ${plan.highlight ? "p-px border-shimmer" : "p-px"} overflow-hidden h-full`}
                  style={{
                    boxShadow: plan.highlight
                      ? "0 0 80px rgba(0,112,243,0.2), 0 0 160px rgba(255,45,120,0.1), 0 40px 100px rgba(0,0,0,0.6)"
                      : "0 0 40px rgba(0,0,0,0.3)",
                    border: plan.highlight ? undefined : "1px solid rgba(255,255,255,0.08)",
                  }}
                >
                  <div
                    className="rounded-3xl overflow-hidden h-full flex flex-col"
                    style={{ background: "rgba(8,12,25,0.95)", backdropFilter: "blur(20px)" }}
                  >
                    {/* Top glow line */}
                    {plan.highlight && (
                      <div className="h-px" style={{ background: "linear-gradient(90deg, transparent, #FF2D78, #0070F3, transparent)" }} />
                    )}

                    <div className="p-8 md:p-10 flex flex-col flex-1">
                      {/* Badge */}
                      <div className="flex items-center justify-between mb-6">
                        <div
                          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-mono font-bold"
                          style={{
                            background: `${plan.badgeColor}15`,
                            border: `1px solid ${plan.badgeColor}40`,
                            color: plan.badgeColor,
                          }}
                        >
                          <plan.icon size={12} className="fill-current" />
                          {plan.badge}
                        </div>
                        {plan.highlight && (
                          <Star size={16} className="fill-current" style={{ color: "#F59E0B" }} />
                        )}
                      </div>

                      {/* Plan name */}
                      <h3 className="font-mono font-bold text-xl mb-2" style={{ color: "var(--text-primary)" }}>
                        {plan.name}
                      </h3>
                      <p className="text-sm mb-6 leading-relaxed" style={{ color: "var(--text-muted)" }}>
                        {plan.desc}
                      </p>

                      {/* Price */}
                      <div className="mb-6">
                        <div className="flex items-baseline gap-2 mb-1">
                          <span
                            className="text-5xl font-mono font-bold tracking-tighter"
                            style={{ color: "white" }}
                          >
                            {plan.monthlyLabel}
                          </span>
                          <span className="text-base font-mono" style={{ color: "var(--text-muted)" }}>
                            /mese
                          </span>
                        </div>

                        {/* Setup prominente */}
                        <div
                          className="rounded-xl p-4 mt-4 flex flex-col gap-3"
                          style={{
                            background: "linear-gradient(135deg, rgba(255,45,120,0.06), rgba(123,47,255,0.04))",
                            border: "1px solid rgba(255,45,120,0.2)",
                          }}
                        >
                          {/* Setup una tantum — grande e visibile */}
                          <div className="flex items-center justify-between">
                            <div className="flex flex-col">
                              <span className="text-[10px] font-mono uppercase tracking-widest mb-0.5" style={{ color: "rgba(255,45,120,0.7)" }}>
                                Pagamento iniziale
                              </span>
                              <span className="text-xs font-mono" style={{ color: "var(--text-muted)" }}>
                                Setup una tantum + IVA
                              </span>
                            </div>
                            <span className="text-2xl font-mono font-black tracking-tight" style={{ color: "#FF2D78" }}>
                              {plan.setupLabel}
                            </span>
                          </div>

                          <div className="h-px" style={{ background: "rgba(255,255,255,0.08)" }} />

                          {/* Canone mensile */}
                          <div className="flex items-center justify-between">
                            <div className="flex flex-col">
                              <span className="text-[10px] font-mono uppercase tracking-widest mb-0.5" style={{ color: "rgba(0,112,243,0.7)" }}>
                                Canone ricorrente
                              </span>
                              <span className="text-xs font-mono" style={{ color: "var(--text-muted)" }}>
                                Addebito mensile
                              </span>
                            </div>
                            <span className="text-lg font-mono font-bold" style={{ color: "var(--text-primary)" }}>
                              {plan.monthlyLabel}<span className="text-xs font-normal" style={{ color: "var(--text-muted)" }}>/mese</span>
                            </span>
                          </div>

                          <div className="h-px" style={{ background: "rgba(255,255,255,0.08)" }} />

                          {/* Totale primo anno */}
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-mono font-bold" style={{ color: "var(--text-muted)" }}>
                              Totale primo anno
                            </span>
                            <span className="text-base font-mono font-black" style={{ color: "var(--blue-bright)" }}>
                              €{new Intl.NumberFormat("it-IT").format(Math.round(plan.setup + plan.monthly * 12))}
                            </span>
                          </div>
                        </div>
                      </div>

                      <p className="text-xs font-mono mb-6" style={{ color: "var(--text-muted)" }}>
                        Operativo in 7 giorni · Disdici quando vuoi · Nessun vincolo
                      </p>

                      {/* Features */}
                      <div className="flex flex-col gap-3 mb-6 flex-1">
                        {plan.features.map((feat, i) => (
                          <div key={i} className="flex items-start gap-2.5">
                            <div
                              className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 mt-0.5"
                              style={{ background: "rgba(0,199,129,0.08)", border: "1px solid rgba(0,199,129,0.15)" }}
                            >
                              <Check size={9} style={{ color: "#00C781" }} />
                            </div>
                            <span className="text-sm font-mono" style={{ color: "var(--text-secondary)" }}>
                              {feat}
                            </span>
                          </div>
                        ))}
                        {plan.notIncluded.map((feat, i) => (
                          <div key={`no-${i}`} className="flex items-start gap-2.5 opacity-40">
                            <div
                              className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 mt-0.5"
                              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
                            >
                              <X size={9} style={{ color: "var(--text-muted)" }} />
                            </div>
                            <span className="text-sm font-mono" style={{ color: "var(--text-muted)" }}>
                              {feat}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* CTA */}
                      <motion.button
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={() => handleCheckout(plan.id)}
                        disabled={checkoutLoading !== null}
                        className="group inline-flex items-center justify-center gap-2.5 w-full px-6 py-4 rounded-xl font-mono font-bold text-sm text-white transition-all disabled:opacity-70"
                        style={{
                          background: plan.highlight
                            ? "linear-gradient(135deg, #0070F3, #7B2FFF)"
                            : "rgba(255,255,255,0.06)",
                          boxShadow: plan.highlight
                            ? "0 0 40px rgba(0,112,243,0.4), 0 8px 32px rgba(0,0,0,0.4)"
                            : "none",
                          border: plan.highlight ? "none" : "1px solid rgba(255,255,255,0.1)",
                        }}
                      >
                        {checkoutLoading === plan.id ? (
                          <>
                            <Loader2 size={16} className="animate-spin" />
                            Reindirizzamento a Stripe...
                          </>
                        ) : (
                          <>
                            <Zap size={16} />
                            {plan.ctaLabel}
                            <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
                          </>
                        )}
                      </motion.button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* ── SERVIZI INCLUSI ───────────────────────────────────── */}
        <section className="py-28 px-6">
          <div className="max-w-6xl mx-auto">
            <motion.div
              {...fadeUpView(0)}
              className="text-center mb-16"
            >
              <p className="text-xs font-mono font-semibold mb-5 tracking-[0.3em] uppercase" style={{ color: "var(--blue)" }}>
                COSA INCLUDE OGNI PIANO
              </p>
              <h2 className="font-mono text-3xl md:text-4xl lg:text-5xl font-bold mb-5">
                <span style={{ color: "var(--text-primary)" }}>6 servizi.</span>{" "}
                <span className="gradient-blue">Scelti per te.</span>
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {services.map((s, i) => (
                <motion.div
                  key={i}
                  {...fadeUpView(i * 0.08)}
                  className="rounded-2xl p-6 relative overflow-hidden card-interactive-blue"
                >
                  <div className="relative">
                    <div className="flex items-center justify-between mb-4">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{ background: "rgba(0,112,243,0.08)", border: "1px solid rgba(0,112,243,0.15)" }}
                      >
                        <s.icon size={18} style={{ color: "var(--blue-bright)" }} />
                      </div>
                      <div className="flex gap-1">
                        {s.plans.map((p) => (
                          <span
                            key={p}
                            className="text-[8px] font-mono px-1.5 py-0.5 rounded-full"
                            style={{
                              background: p === "enterprise" ? "rgba(255,45,120,0.08)" : p === "professional" ? "rgba(0,112,243,0.08)" : "rgba(100,116,139,0.08)",
                              color: p === "enterprise" ? "#FF2D78" : p === "professional" ? "var(--blue)" : "#64748b",
                              border: `1px solid ${p === "enterprise" ? "rgba(255,45,120,0.15)" : p === "professional" ? "rgba(0,112,243,0.15)" : "rgba(100,116,139,0.15)"}`,
                            }}
                          >
                            {p === "starter" ? "S" : p === "professional" ? "P" : "E"}
                          </span>
                        ))}
                      </div>
                    </div>
                    <h3 className="font-mono font-semibold text-base mb-2" style={{ color: "var(--text-primary)" }}>
                      {s.title}
                    </h3>
                    <p className="text-sm leading-relaxed" style={{ color: "var(--text-muted)" }}>
                      {s.desc}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CHECKLIST TUTTO INCLUSO (Professional + Enterprise) ─ */}
        <section className="py-28 px-6">
          <div className="max-w-3xl mx-auto">
            <motion.div
              {...fadeUpView(0)}
              className="text-center mb-14"
            >
              <p className="text-xs font-mono font-semibold mb-5 tracking-[0.3em] uppercase" style={{ color: "var(--blue)" }}>
                ZERO COSTI NASCOSTI
              </p>
              <h2 className="font-mono text-3xl md:text-4xl lg:text-5xl font-bold">
                Incluso nei piani con AI.{" "}
                <span className="gradient-blue">Tutto.</span>
              </h2>
            </motion.div>

            <motion.div
              {...fadeUpView(0.1)}
              className="rounded-2xl p-8 md:p-10 glass"
            >
              <div className="grid sm:grid-cols-2 gap-4">
                {included.map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.04, duration: 0.4, ease }}
                    className="flex items-start gap-3"
                  >
                    <div
                      className="w-5 h-5 rounded flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{ background: "rgba(0,199,129,0.08)", border: "1px solid rgba(0,199,129,0.15)" }}
                    >
                      <Check size={11} style={{ color: "#00C781" }} />
                    </div>
                    <span className="text-sm font-mono" style={{ color: "var(--text-secondary)" }}>
                      {item}
                    </span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* ── FAQ ────────────────────────────────────────────────── */}
        <section className="py-28 px-6">
          <div className="max-w-3xl mx-auto">
            <motion.div
              {...fadeUpView(0)}
              className="text-center mb-14"
            >
              <p className="text-xs font-mono font-semibold mb-5 tracking-[0.3em] uppercase" style={{ color: "var(--blue)" }}>
                DOMANDE FREQUENTI
              </p>
              <h2 className="font-mono text-3xl md:text-4xl lg:text-5xl font-bold">
                Prima che tu chieda.
              </h2>
            </motion.div>

            <div className="flex flex-col gap-4">
              {faqs.map((faq, i) => (
                <motion.div
                  key={i}
                  {...fadeUpView(i * 0.06)}
                  className="rounded-xl p-6 card-interactive"
                >
                  <h3 className="font-mono font-semibold text-sm mb-3" style={{ color: "var(--text-primary)" }}>
                    {faq.q}
                  </h3>
                  <p className="text-sm leading-relaxed" style={{ color: "var(--text-muted)" }}>
                    {faq.a}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA FINALE ─────────────────────────────────────────── */}
        <section className="py-32 px-6 text-center relative overflow-hidden">
          <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />

          <motion.div
            {...fadeUpView(0)}
            className="max-w-3xl mx-auto relative z-10"
          >
            <p className="text-xs font-mono font-semibold mb-6 tracking-[0.3em] uppercase" style={{ color: "var(--blue)" }}>
              LA SCELTA E&apos; SEMPLICE
            </p>
            <h2 className="font-mono text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Da €24,99/mese per il sito,<br />
              <span className="gradient-hero">
                da €149,99/mese con l&apos;AI.
              </span>
            </h2>
            <p className="text-lg mb-14" style={{ color: "var(--text-secondary)" }}>
              Il setup si ripaga al primo cliente chiuso con l&apos;AI.
              Tutto il resto è profitto netto.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => handleCheckout("professional")}
                disabled={checkoutLoading !== null}
                className="group inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-xl font-mono font-bold text-base text-white transition-all hover:scale-105 disabled:opacity-70"
                style={{
                  background: "linear-gradient(135deg, #0070F3, #7B2FFF)",
                  boxShadow: "0 0 40px rgba(0,112,243,0.3), 0 8px 32px rgba(0,0,0,0.4)",
                }}
              >
                {checkoutLoading ? (
                  <Loader2 size={18} className="animate-spin" />
                ) : (
                  <Zap size={18} />
                )}
                INIZIA CON PROFESSIONAL
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </button>
              <a
                href="mailto:info@auraproptech.io"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-mono font-semibold text-base transition-all hover:scale-105 glass"
                style={{ color: "var(--blue-bright)" }}
              >
                <Headphones size={16} />
                Parla con noi
              </a>
            </div>
          </motion.div>
        </section>

      </main>

      {/* Footer */}
      <footer className="py-10 px-6 text-center relative z-10" style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
        <div className="flex items-center justify-center gap-2.5 mb-4">
          <div
            className="w-6 h-6 rounded-md flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #0070F3, #7B2FFF)" }}
          >
            <Zap size={11} className="text-white" />
          </div>
          <span className="font-mono font-bold text-sm">
            AURA<span className="gradient-blue">PROPTECH</span>
          </span>
        </div>
        <p className="text-xs font-mono" style={{ color: "var(--text-muted)" }}>
          © 2026 Aura PropTech · Built in Italy · Powered by Gemini AI
        </p>
      </footer>
    </div>
  );
}
